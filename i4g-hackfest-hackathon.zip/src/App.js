import "./styles.css";
import SignUp from "./Components/SignUp";
export default function App() {
  return (
    <>
      <SignUp />
    </>
  );
}
